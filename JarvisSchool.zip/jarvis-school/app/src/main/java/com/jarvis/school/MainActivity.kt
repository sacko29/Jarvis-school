package com.jarvis.school

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class SchoolTask(
    val id: Long,
    var title: String,
    var subject: String,
    var category: String,
    var due: String,
    var done: Boolean
) {
    fun toJson() = JSONObject().put("id", id).put("title", title).put("subject", subject)
        .put("category", category).put("due", due).put("done", done)
    companion object {
        fun fromJson(o: JSONObject) = SchoolTask(o.optLong("id"), o.optString("title"), o.optString("subject"),
            o.optString("category", "Maison"), o.optString("due"), o.optBoolean("done"))
    }
}

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 11, 20)
    private val panel = Color.rgb(15, 23, 39)
    private val cyan = Color.rgb(67, 217, 255)
    private val white = Color.rgb(235, 245, 255)
    private val muted = Color.rgb(139, 160, 184)
    private val prefs by lazy { getSharedPreferences("jarvis_school", MODE_PRIVATE) }
    private val tasks = mutableListOf<SchoolTask>()
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var page = "Accueil"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        loadTasks()
        showShell()
    }

    private fun loadTasks() {
        tasks.clear()
        val raw = prefs.getString("tasks", "[]") ?: "[]"
        try { val a = JSONArray(raw); for (i in 0 until a.length()) tasks.add(SchoolTask.fromJson(a.getJSONObject(i))) } catch (_: Exception) { }
    }
    private fun saveTasks() {
        val a = JSONArray(); tasks.forEach { a.put(it.toJson()) }
        prefs.edit().putString("tasks", a.toString()).apply()
    }

    private fun showShell() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(18), dp(14), dp(18), dp(10)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(text("J.A.R.V.I.S.", 22f, cyan, true))
        brand.addView(text("SCHOOL SYSTEM  /  v0.1", 10f, muted, false))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val status = text("● LOCAL", 11f, cyan, true).apply { setPadding(dp(10), dp(7), dp(10), dp(7)); background = rounded(panel, 16) }
        header.addView(status)
        root.addView(header)
        val line = View(this).apply { setBackgroundColor(Color.rgb(27, 53, 73)) }
        root.addView(line, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(14); bottomMargin = dp(12) })
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(4)) }
        listOf("Accueil", "Missions", "Révisions", "Jarvis").forEach { name ->
            val b = TextView(this).apply {
                text = name; textSize = 11f; gravity = Gravity.CENTER; setTextColor(if (page == name) cyan else muted)
                setPadding(dp(7), dp(12), dp(7), dp(12)); setOnClickListener { page = name; showPage() }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
        showPage()
    }

    private fun showPage() {
        content.removeAllViews()
        when (page) {
            "Accueil" -> showHome()
            "Missions" -> showTasks()
            "Révisions" -> showRevisions()
            else -> showJarvis()
        }
    }

    private fun showHome() {
        val hour = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        content.addView(text("TABLEAU DE BORD", 11f, muted, true).apply { setPadding(0, dp(8), 0, dp(7)) })
        content.addView(text("Bonjour. Prêt à avancer ?", 24f, white, true))
        content.addView(text("Il est $hour — voici votre situation.", 13f, muted, false).apply { setPadding(0, dp(5), 0, dp(16)) })
        val pending = tasks.count { !it.done }
        val done = tasks.count { it.done }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(statCard("À FAIRE", pending.toString(), "missions actives"), LinearLayout.LayoutParams(0, dp(104), 1f).apply { rightMargin = dp(7) })
        row.addView(statCard("TERMINÉ", done.toString(), "missions validées"), LinearLayout.LayoutParams(0, dp(104), 1f).apply { leftMargin = dp(7) })
        content.addView(row)
        section("PRIORITÉS DU JOUR")
        val next = tasks.filter { !it.done }.take(3)
        if (next.isEmpty()) content.addView(infoCard("Aucune mission en attente.", "Ajoutez un devoir ou une révision pour commencer."))
        else next.forEach { content.addView(taskCard(it, compact = true)) }
        section("ACCÈS RAPIDE")
        content.addView(actionButton("＋  Ajouter une mission") { addTaskDialog() })
        content.addView(actionButton("◎  Voir toutes les missions") { page = "Missions"; showPage() })
        content.addView(text("Les données sont conservées sur cet appareil. La voix IA et les alarmes Android ne sont pas encore intégrées dans cette première version.", 11f, muted, false).apply { setPadding(2, dp(15), 2, dp(12)) })
    }

    private fun showTasks() {
        content.addView(text("MISSIONS", 12f, cyan, true).apply { setPadding(0, dp(8), 0, dp(4)) })
        content.addView(text("Devoirs, cours à reprendre et tâches personnelles.", 13f, muted, false).apply { setPadding(0, 0, 0, dp(12)) })
        content.addView(actionButton("＋  Ajouter une mission") { addTaskDialog() })
        if (tasks.isEmpty()) content.addView(infoCard("Votre liste est vide.", "Ajoutez votre premier devoir ou chapitre à réviser."))
        tasks.sortedWith(compareBy<SchoolTask> { it.done }.thenBy { it.due }).forEach { content.addView(taskCard(it, compact = false)) }
    }

    private fun showRevisions() {
        content.addView(text("RÉVISIONS ESPACÉES", 12f, cyan, true).apply { setPadding(0, dp(8), 0, dp(4)) })
        content.addView(text("Centralisez les chapitres à revoir. La planification automatique adaptative sera ajoutée dans une prochaine version.", 13f, muted, false).apply { setPadding(0, 0, 0, dp(14)) })
        val revisions = tasks.filter { it.category == "Révision" }
        if (revisions.isEmpty()) content.addView(infoCard("Aucune révision enregistrée.", "Ajoutez une mission et choisissez la catégorie Révision."))
        revisions.forEach { content.addView(taskCard(it, compact = false)) }
        content.addView(actionButton("＋  Ajouter une révision") { addTaskDialog(defaultCategory = "Révision") })
    }

    private fun showJarvis() {
        content.addView(text("J.A.R.V.I.S. / ASSISTANT", 12f, cyan, true).apply { setPadding(0, dp(8), 0, dp(12)) })
        val orb = TextView(this).apply {
            text = "J"; textSize = 58f; typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); textColor = cyan
            gravity = Gravity.CENTER; background = rounded(Color.rgb(12, 35, 53), 100); elevation = dp(5).toFloat()
        }
        content.addView(orb, LinearLayout.LayoutParams(dp(132), dp(132)).apply { gravity = Gravity.CENTER; bottomMargin = dp(15) })
        content.addView(text("SYSTÈME LOCAL ACTIF", 13f, white, true).apply { gravity = Gravity.CENTER })
        content.addView(text("Les commandes vocales et la conversation IA ne sont pas encore disponibles dans cette version. Pour le moment, utilisez les missions et les révisions.", 13f, muted, false).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(12), dp(8), dp(18)) })
        content.addView(actionButton("＋  Créer une mission") { addTaskDialog() })
        content.addView(infoCard("Fonctions prévues", "Commandes vocales • Mode hors ligne • Rappels • Déplacement de séances • IA en ligne"))
    }

    private fun addTaskDialog(defaultCategory: String = "Devoir école") {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val title = EditText(this).apply { hint = "Ex. Exercices de fonctions"; setSingleLine(true); setTextColor(white); setHintTextColor(muted) }
        val subject = EditText(this).apply { hint = "Matière (ex. Mathématiques)"; setSingleLine(true); setTextColor(white); setHintTextColor(muted) }
        val categories = arrayOf("Devoir école", "Devoir prof", "Révision", "Cours à recopier", "Personnel")
        val spinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, categories); setSelection(categories.indexOf(defaultCategory).coerceAtLeast(0)) }
        val due = EditText(this).apply { hint = "Échéance (ex. jeudi, facultatif)"; setSingleLine(true); setTextColor(white); setHintTextColor(muted) }
        listOf(title, subject, spinner, due).forEach { box.addView(it, LinearLayout.LayoutParams(-1, dp(52))) }
        AlertDialog.Builder(this).setTitle("Nouvelle mission").setView(box)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer") { _, _ ->
                val t = title.text.toString().trim()
                if (t.isNotEmpty()) {
                    tasks.add(SchoolTask(System.currentTimeMillis(), t, subject.text.toString().trim(), categories[spinner.selectedItemPosition], due.text.toString().trim(), false))
                    saveTasks(); showPage()
                } else Toast.makeText(this, "Entre au moins un titre.", Toast.LENGTH_SHORT).show()
            }.show().apply { getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(cyan); getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(muted) }
    }

    private fun taskCard(task: SchoolTask, compact: Boolean): View {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(13), dp(12), dp(13), dp(10)); background = rounded(panel, 16) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val check = CheckBox(this).apply { isChecked = task.done; buttonTintList = android.content.res.ColorStateList.valueOf(cyan); setOnCheckedChangeListener { _, checked -> task.done = checked; saveTasks(); showPage() } }
        top.addView(check)
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(text(task.title, 15f, if (task.done) muted else white, true))
        val meta = listOf(task.subject, task.category, task.due.takeIf { it.isNotBlank() }?.let { "Échéance : $it" }).filterNotNull().joinToString("  •  ")
        titleCol.addView(text(meta.ifBlank { "Aucune matière indiquée" }, 11f, muted, false).apply { setPadding(0, dp(4), 0, 0) })
        top.addView(titleCol, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(top)
        if (!compact) {
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
            val edit = TextView(this).apply { text = "MODIFIER"; textSize = 10f; setTextColor(cyan); setPadding(dp(8), dp(8), dp(8), dp(3)); setOnClickListener { editTask(task) } }
            val delete = TextView(this).apply { text = "SUPPRIMER"; textSize = 10f; setTextColor(Color.rgb(255, 125, 140)); setPadding(dp(8), dp(8), dp(2), dp(3)); setOnClickListener { AlertDialog.Builder(this@MainActivity).setMessage("Supprimer cette mission ?").setNegativeButton("Annuler", null).setPositiveButton("Supprimer") { _, _ -> tasks.removeAll { it.id == task.id }; saveTasks(); showPage() }.show() } }
            actions.addView(edit); actions.addView(delete); card.addView(actions)
        }
        val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) }
        card.layoutParams = lp
        return card
    }

    private fun editTask(task: SchoolTask) {
        val input = EditText(this).apply { setText(task.title); setTextColor(white); setHintTextColor(muted) }
        AlertDialog.Builder(this).setTitle("Modifier la mission").setView(input).setNegativeButton("Annuler", null).setPositiveButton("Enregistrer") { _, _ ->
            val value = input.text.toString().trim(); if (value.isNotEmpty()) { task.title = value; saveTasks(); showPage() }
        }.show()
    }

    private fun statCard(label: String, value: String, caption: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(13), dp(13), dp(10), dp(10)); background = rounded(panel, 16)
        addView(text(label, 10f, muted, true)); addView(text(value, 29f, cyan, true).apply { setPadding(0, dp(3), 0, 0) }); addView(text(caption, 10f, muted, false))
    }
    private fun infoCard(title: String, body: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(panel, 15)
        addView(text(title, 14f, white, true)); addView(text(body, 12f, muted, false).apply { setPadding(0, dp(5), 0, 0) })
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
    }
    private fun section(label: String) { content.addView(text(label, 11f, cyan, true).apply { setPadding(0, dp(19), 0, dp(9)) }) }
    private fun actionButton(label: String, action: () -> Unit): View = TextView(this).apply {
        text = label; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(cyan); gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(15), dp(14), dp(15), dp(14)); background = rounded(Color.rgb(10, 29, 44), 14); setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) }
    }
    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), Color.rgb(28, 57, 77)) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
