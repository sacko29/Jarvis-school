# JARVIS SCHOOL — Android native MVP

Première base native Android en Kotlin, avec interface sombre futuriste, navigation Accueil/Missions/Révisions/Jarvis, ajout/modification/suppression de missions, marquage terminé et stockage local persistant via SharedPreferences.

## Ouvrir le projet
1. Décompresser `JarvisSchool.zip`.
2. Ouvrir le dossier `JarvisSchool` dans Android Studio.
3. Autoriser la synchronisation Gradle et l'installation des composants Android demandés.
4. Lancer sur un appareil Android ou un émulateur.

## Important — état réel de cette version
- C'est un projet Android natif (Kotlin), pas une maquette web.
- Les missions sont conservées localement et fonctionnent hors ligne.
- La planification avancée, les alarmes système, la reconnaissance/synthèse vocale, l'IA en ligne, les pièces jointes et la répétition espacée adaptative ne sont pas encore implémentées.
- Aucun APK précompilé n'est fourni : cet environnement ne dispose pas du SDK Android ni de Gradle installés pour compiler et tester l'APK ici. Android Studio devra synchroniser les dépendances et compiler le projet.
